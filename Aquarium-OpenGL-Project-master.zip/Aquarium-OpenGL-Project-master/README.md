# Aquarium-OpenGL-Project
This is the Aquarium simulator using OpenGL library in C Language

This project simulate the fish tank scenary.
there are two golden fish and one Big Shark, which moves right to left and left to right
This also has a cute frog and plants, diffrent colored stones and a big vine

this has good front page where you can mention your name, college name, teammate name, project guide name

when you press P the animation starts
initially the fishes are not moving 
you have to click the mouse button then a menu pop ups there you have to select the move option
you can also stop the animation, go back to front screen and quit the animation
when you press i fish movement speed gets increases and when you press d it will decreases

you can also add many different features that you want

soo this is the an amezing project try it onece....
